package tat16.microFramework.command.exception;

public class CommandException extends FrameworkException {

	private static final long serialVersionUID = 2808367558196239295L;

	public CommandException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CommandException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public CommandException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public CommandException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public CommandException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
