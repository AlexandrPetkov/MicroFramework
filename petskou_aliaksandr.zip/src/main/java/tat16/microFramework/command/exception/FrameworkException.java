package tat16.microFramework.command.exception;

public class FrameworkException extends Exception {

	private static final long serialVersionUID = -444331541237148785L;

	public FrameworkException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FrameworkException(String arg0, Throwable arg1, boolean arg2, boolean arg3) {
		super(arg0, arg1, arg2, arg3);
		// TODO Auto-generated constructor stub
	}

	public FrameworkException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	public FrameworkException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public FrameworkException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

}
